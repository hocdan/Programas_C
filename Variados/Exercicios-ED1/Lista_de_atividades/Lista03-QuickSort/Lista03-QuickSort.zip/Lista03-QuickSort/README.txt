Aluno: Daniel Sousa Gonçalves.
Ferramenta utilizada: NotePad++ com compilador gcc.
Ambiente de execução: Windows 10.