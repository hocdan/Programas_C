#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define TRUE 1
#define FALSE 0

int main(){
    //constantes do programa
    const int largura = 40; //dimensao do eixo x
    const int altura = 40; //dimensao do eixo y
    const int N = largura*altura; //total de pontos do vetor
    const float c1 = -1.1;
    const float c2 = 0.125;
    const int n = 5; //numero de iteracoes no calculo do fractal
    
    //variaveis do programa
    int pontos[N]; //onde ira armazenar apenas 1 ou 0 ( ou seja, se o ponto (i, j) tende ou nao tende ao infinito)
    int i, j, k, index = 0, pertence; //contadores e flag de controle do calculo
    double x0, y0, x1, y1, distancia; //vao armazenar valores intermediarios no calculo
    
    //ALGORITMO
    for (i=1; i<=largura; i++){
        for (j=1; j<=altura; j++){
            x0 = ((double)i/ (double) 200) - 2;
            y0 = 2 - ( (double) j/ (double) 200);
            pertence = TRUE;
            /*
            printf("\nAplicando no ponto ( %d, %d)...\n", i, j);
            printf("Valor de x0 = %lf\n Valor de y0 = %lf\n", x0, y0);
            system("pause");
            */
            //aplicando pontos na funcao em n iteracoes
            for (k=0; k<n; k++){
                x1 = pow(x0, 2) - pow(y0, 2) + c1;
                y1 = (2*x0*y0) + c2;
                distancia = pow(x1, 2) + pow(y1, 2);
                /*
                printf("Iteracao %d:\n Valor de x1 = %lf\n Valor de y1 = %lf\n Distancia = %lf\n", k, x1, y1, distancia);
                system("pause");
                */
                //verificando se o ponto tende ao infinito
                if ( distancia > 2){
                    //printf("Tende ao infinito...\n");
                    pertence = FALSE; //nao esta dentro do fractal
                    break; //encerrando iteracoes sobre o ponto
                }
                else{
                    //se o ponto ainda esta dentro do fractal...continuar iteracoes
                    x0 = x1;
                    y0 = y1;
                }
            }
            //se ao final das iteracoes o ponto estiver dentro do fractal...
            if ( pertence ) {
                pontos[index] = TRUE;
                //printf("O ponto (%d, %d) esta dentro do fractal!\n", i, j);
            }
            else {
                pontos[index] = FALSE;
                //printf("O ponto (%d, %d) nao esta dentro do fractal!\n", i, j);
            }
            index++; //atualizando posicao a ser preenchida no vetor
            //system("pause");
            //*/
        }
    }
    //mostrando vetor em forma de matriz
    for (i=0; i<N; i++){
        if ( i%largura == 0) printf("\n");
        if ( pontos[i] == 0) printf("*");
        else printf(" ");
    }

    system("pause");
    
    return 0;
}