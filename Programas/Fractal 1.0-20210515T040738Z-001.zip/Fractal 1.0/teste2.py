largura = 50
altura = 50
c1 = -1.1
c2 = 0.125
n = 5
pontos = []

for i in range(1, largura+1):
    for j in range(1, altura+1):
        x0 = (i/200) - 2
        y0 = 2 - (j/200)
        pertence = True
        #print("\nAplicando no ponto: ({}, {})...".format(i, j))
        #print("Valor de x0 = {}\n Valor de y0 = {}".format(x0, y0))
        for k in range(0, n):
            x1 = pow(x0, 2) - pow(y0, 2) + c1
            y1 = (2*x0*y0) + c2
            distancia = pow(x1, 2) + pow(y1, 2)
            #print("Iteracao {}:\n valor de x1 = {}\n Valor de y1 = {}\n Distancia = {}".format(k, x1, y1, distancia))
            if ( distancia > 2):
                #print("Tende ao infinito...")
                pertence = False
                break
            else:
                x0 = x1
                y0 = y1
        if ( pertence ):
            pontos[i-1].append(1)
            #print("O ponto ({}, {}) esta dentro do fractal!".format(i, j))
        else:
            pontos[i-1].append(0)
            #print("O ponto ({}, {}) nao esta dentro do fractal!".format(i, j))
        #dando tempo para visualizar
        #input("Pressione uma tecla para continuar...")
#imprimindo vetor no formato de matriz
for i in range(0, (largura*altura)):
    if ( i%largura == 0):
        print("") #quebra de linha
        
    if ( pontos[i] == 1):
        print(' ', end='')
    else:
        print('*', end='')
