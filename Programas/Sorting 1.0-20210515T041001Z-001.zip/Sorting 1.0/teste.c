#include <stdio.h>
#include <stdlib.h>

#define N 20
#define TRUE 1
#define FALSE 0

int main(){
    //prototipo da funcao
    void preencherVetor(int vetor[N]);
    void insertionSort(int *vetor, int tam);
    
    int i, vetor[N];
    
    preencherVetor(vetor);
    
    printf("[ ");
    for (i=0; i<N; i++){
        printf("%d ", vetor[i]);
    }
    printf("]\n");
    
    insertionSort(vetor, N);
    
    printf("[ ");
    for (i=0; i<N; i++){
        printf("%d ", vetor[i]);
    }
    printf("]\n");
    
    
    system("pause");
    return 0;
}

void preencherVetor(int vetor[N]){
    int i, j, valido, alet;
    time_t t; //necessario para gerar numeros realmente aleatorios
    
    srand( (unsigned) time(&t)); //seed para gerar os numeros aleatorios
    
    //resetando vetor para assumir novos valores
    for (i=0; i<N; i++){
        vetor[i] = -1; //valor padrao para indicar que o local esta "vazio"
    }
    //preenchendo vetor com valores aleatorios de 0 ate (N-1)
    for (i=0; i<N; i++){
        valido = TRUE; //setando flag
        alet = ( rand() % N); //gerando numero aleatorio
        //buscando se ja existe esse numero no vetor...
        for (j=0; j<i; j++){
            if ( vetor[j] == alet) valido = FALSE;
        }
        if (valido) vetor[i] = alet;
        else i--; //retornando para a mesma posicao e tentando novamente
    }
}

void insertionSort(int *vetor, int tam){
	register int i, j, ponta, temp;

	//passando por todo o vetor e comparando a ponta com seus antecessores
	for (i=1; i<tam; i++){
		ponta = i;
		for (j=(i-1); j>=0; j--){
			//trocando ponta com o resto do vetor caso ela seja menor
			if ( vetor[ponta] < vetor[j]){
				temp = vetor[ponta];
				vetor[ponta] = vetor[j];
				vetor[j] = temp;
				ponta--; //mantendo registro da posicao do elemento ponta
			}
		}
	}
    
    printf("i: %d e j: %d\n", i, j);

}